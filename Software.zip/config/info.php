<?php

return [

    'software' => [
        'name'      => 'phpRank',
        'author'    => 'Lunatio',
        'url'       => 'https://lunatio.com',
        'version'   => '2.0.0'
    ]

];
