<?php
HtmlTemplate::display('global/maintenance_mode');
exit;