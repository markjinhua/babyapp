<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'quickai';
$config['db']['user'] = 'root';
$config['db']['pass'] = '';
$config['db']['pre'] = 'vc_';

$config['admin_folder'] = 'admin';
$config['version'] = '3.9.1';